import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const defaultTrainer = {
  name: 'Тим',
  role: 'Персональный тренер',
  club: 'HITFitness',
  location: 'ТРК «Лео Молл», м. Комендантский проспект',
  formats: 'Очно в зале и онлайн',
  offer: 'Бесплатный фитнес-разбор',
  photo: ''
};

const defaultLeads = [
  {
    id: 1,
    name: 'Анна',
    source: 'Telegram чат ЖК',
    goal: 'Похудеть и подтянуть форму',
    format: 'Очно',
    status: 'Новый лид',
    nextStep: 'Уточнить удобное время',
    followUp: 'Сегодня',
    notes: 'Написала: РАЗБОР'
  },
  {
    id: 2,
    name: 'Игорь',
    source: 'VK районная группа',
    goal: 'Набор мышечной массы',
    format: 'Онлайн',
    status: 'Выбрал формат',
    nextStep: 'Назначить онлайн-разбор',
    followUp: 'Завтра',
    notes: 'Хочет программу тренировок'
  }
];

const defaultPlatforms = [
  { id: 1, name: 'Услуги Приморский / Комендантский', type: 'Telegram', district: 'Приморский район', rules: 'Можно публиковать услуги', status: 'Можно публиковать', lastPost: '—', result: 'Тестируется' },
  { id: 2, name: 'VK районная группа', type: 'VK', district: 'Комендантский проспект', rules: 'Проверить правила перед публикацией', status: 'Нужно согласование', lastPost: '—', result: '—' },
  { id: 3, name: 'Авито Услуги', type: 'Авито', district: 'СПБ', rules: 'Разместить карточку услуги', status: 'Можно публиковать', lastPost: '—', result: '—' }
];

const defaultTemplates = [
  {
    id: 1,
    title: 'Первое сообщение в чат',
    type: 'Публикация',
    text: 'Всем привет! Меня зовут Тим, я тренер в HITFitness в ТРК «Лео Молл», рядом с м. Комендантский проспект. Провожу бесплатный фитнес-разбор: цель, ошибки, программа и план на месяц. Можно очно или онлайн. Кому актуально — напишите в личку: «РАЗБОР».'
  },
  {
    id: 2,
    title: 'Ответ на «РАЗБОР»',
    type: 'Личное сообщение',
    text: 'Привет! Спасибо, что написал(а) 🙌 Меня зовут Тим, я тренер в HITFitness. Подскажи, тебе удобнее сделать разбор очно в зале или онлайн? Очно можем встретиться в HITFitness в ТРК «Лео Молл», онлайн — в переписке или созвоне.'
  },
  {
    id: 3,
    title: 'Follow-up после молчания',
    type: 'Follow-up',
    text: 'Привет! Напомню про фитнес-разбор. Могу коротко подсказать, с чего начать именно в твоей ситуации. Удобнее очно или онлайн?'
  }
];

const defaultOutbox = [
  { id: 1, channel: 'Telegram / чат услуг', title: 'Пост: бесплатный фитнес-разбор', status: 'Ожидает подтверждения', scheduled: 'Сегодня, 18:30' },
  { id: 2, channel: 'Анна / личные сообщения', title: 'Ответ на «РАЗБОР»', status: 'Ожидает подтверждения', scheduled: 'Сейчас' }
];

const defaultBookings = [
  { id: 1, client: 'Анна', type: 'Очный разбор', date: 'Сегодня', time: '19:00', status: 'Ожидает подтверждения' },
  { id: 2, client: 'Игорь', type: 'Онлайн-разбор', date: 'Завтра', time: '12:30', status: 'Слот предложен' }
];

const statuses = ['Новый лид', 'Ответил', 'Выбрал формат', 'Назначен разбор', 'Прошел разбор', 'Записан на тренировку', 'Купил пакет', 'Думает', 'Отказ', 'Написать позже'];
const tabs = [
  ['dashboard', 'Главная'],
  ['leads', 'Лиды'],
  ['messages', 'Сообщения'],
  ['calendar', 'Запись'],
  ['platforms', 'Площадки'],
  ['templates', 'Шаблоны'],
  ['client', 'Анкета'],
  ['analytics', 'Аналитика'],
  ['profile', 'Профиль']
];

function useStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);
  return [value, setValue];
}

function Button({ children, variant = 'dark', ...props }) {
  return <button className={`btn ${variant}`} {...props}>{children}</button>;
}

function Card({ children, className = '' }) {
  return <section className={`card ${className}`}>{children}</section>;
}

function Input(props) {
  return <input className="input" {...props} />;
}

function Select(props) {
  return <select className="input" {...props} />;
}

function Textarea(props) {
  return <textarea className="input textarea" {...props} />;
}

function Sidebar({ tab, setTab }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brandIcon">T</div>
        <div>
          <b>TimFit CRM</b>
          <span>тренер + клиенты</span>
        </div>
      </div>
      <nav>
        {tabs.map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} className={tab === id ? 'active' : ''}>{label}</button>
        ))}
      </nav>
      <div className="safeBox">
        <b>Безопасный режим</b>
        <p>Приложение готовит тексты и напоминания, а отправку подтверждает тренер.</p>
      </div>
    </aside>
  );
}

function Header({ trainer }) {
  return (
    <header className="header">
      <div>
        <p className="eyebrow">{trainer.club} • {trainer.location}</p>
        <h1>Приложение для тренера и клиентов</h1>
        <p>CRM, заявки, запись, шаблоны, площадки и почти автоматические follow-up сообщения.</p>
      </div>
    </header>
  );
}

function Stat({ label, value, sub }) {
  return (
    <Card className="stat">
      <p>{label}</p>
      <strong>{value}</strong>
      <span>{sub}</span>
    </Card>
  );
}

function Dashboard({ leads, platforms, outbox, bookings, setTab }) {
  return (
    <div className="page">
      <div className="stats">
        <Stat label="Лиды" value={leads.length} sub="в базе" />
        <Stat label="Записи" value={bookings.length} sub="разборы и тренировки" />
        <Stat label="Очередь" value={outbox.length} sub="на подтверждение" />
        <Stat label="Площадки" value={platforms.length} sub="для продвижения" />
      </div>

      <div className="grid two">
        <Card>
          <div className="sectionHead">
            <div>
              <h2>План на сегодня</h2>
              <p>Минимум действий, которые дают поток заявок.</p>
            </div>
            <Button variant="light" onClick={() => setTab('messages')}>Открыть очередь</Button>
          </div>
          <div className="checkGrid">
            {[
              'Проверить ответы и создать карточки лидов',
              'Подтвердить сообщения в очереди',
              'Опубликовать 1 полезный пост',
              'Назначить время тем, кто написал «РАЗБОР»',
              'Сделать follow-up тем, кто молчит больше 24 часов',
              'Обновить результаты по площадкам'
            ].map((item) => <div className="check" key={item}>✓ {item}</div>)}
          </div>
        </Card>

        <Card className="funnel">
          <h2>Воронка клиента</h2>
          {['Пост / чат', 'Сообщение «РАЗБОР»', 'Консультация', 'Первая тренировка', 'Пакет 8–12 тренировок'].map((s, i) => (
            <div key={s} className="step"><span>{i + 1}</span>{s}</div>
          ))}
        </Card>
      </div>

      <Card>
        <h2>Ближайшие записи</h2>
        <div className="cardsList">
          {bookings.map((b) => (
            <div className="row" key={b.id}>
              <div><b>{b.client}</b><p>{b.type} • {b.date}, {b.time}</p></div>
              <em>{b.status}</em>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Leads({ leads, setLeads }) {
  const [form, setForm] = useState({ name: '', source: '', goal: '', format: 'Очно', notes: '' });
  const [q, setQ] = useState('');
  const filtered = leads.filter((l) => Object.values(l).join(' ').toLowerCase().includes(q.toLowerCase()));

  function addLead() {
    if (!form.name.trim()) return;
    setLeads([{ id: Date.now(), ...form, status: 'Новый лид', nextStep: 'Ответить и уточнить формат', followUp: 'Сегодня' }, ...leads]);
    setForm({ name: '', source: '', goal: '', format: 'Очно', notes: '' });
  }
  function updateLead(id, patch) {
    setLeads(leads.map((l) => l.id === id ? { ...l, ...patch } : l));
  }

  return (
    <div className="grid three">
      <Card>
        <h2>Новый лид</h2>
        <p>Записывай каждого, кто написал «РАЗБОР».</p>
        <div className="form">
          <Input placeholder="Имя" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input placeholder="Источник" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} />
          <Input placeholder="Цель клиента" value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })} />
          <Select value={form.format} onChange={(e) => setForm({ ...form, format: e.target.value })}>
            <option>Очно</option><option>Онлайн</option><option>Не выбрал</option>
          </Select>
          <Textarea placeholder="Заметки" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          <Button onClick={addLead}>Добавить</Button>
        </div>
      </Card>
      <Card className="wide">
        <div className="sectionHead"><h2>База лидов</h2><Input placeholder="Поиск" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="cardsList">
          {filtered.map((lead) => (
            <div className="lead" key={lead.id}>
              <div>
                <h3>{lead.name}</h3>
                <p>{lead.source} • {lead.format}</p>
                <p><b>Цель:</b> {lead.goal || 'не указана'}</p>
                <p><b>Шаг:</b> {lead.nextStep}</p>
              </div>
              <div className="leadControls">
                <Select value={lead.status} onChange={(e) => updateLead(lead.id, { status: e.target.value })}>{statuses.map((s) => <option key={s}>{s}</option>)}</Select>
                <Input value={lead.followUp} onChange={(e) => updateLead(lead.id, { followUp: e.target.value })} />
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Messages({ templates, outbox, setOutbox }) {
  const [templateId, setTemplateId] = useState(2);
  const template = templates.find((t) => t.id === Number(templateId)) || templates[0];
  const [draft, setDraft] = useState(template?.text || '');
  useEffect(() => setDraft(template?.text || ''), [templateId]);

  function addToQueue() {
    setOutbox([{ id: Date.now(), channel: 'Ручная отправка', title: template.title, status: 'Ожидает подтверждения', scheduled: 'Сейчас', text: draft }, ...outbox]);
  }
  function approve(id) {
    setOutbox(outbox.map((m) => m.id === id ? { ...m, status: 'Подтверждено' } : m));
  }

  return (
    <div className="grid two">
      <Card>
        <h2>Помощник переписки</h2>
        <p>Выбери шаблон, поправь и добавь в очередь.</p>
        <div className="form">
          <Select value={templateId} onChange={(e) => setTemplateId(e.target.value)}>{templates.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</Select>
          <Textarea value={draft} onChange={(e) => setDraft(e.target.value)} />
          <div className="hint">Подсказка: сначала спроси формат — очно в HITFitness или онлайн.</div>
          <Button onClick={addToQueue}>Добавить в очередь</Button>
        </div>
      </Card>
      <Card>
        <h2>Очередь отправки</h2>
        <p>Приложение готовит, тренер подтверждает.</p>
        <div className="cardsList">
          {outbox.map((m) => (
            <div className="row" key={m.id}>
              <div><b>{m.title}</b><p>{m.channel} • {m.scheduled}</p><em>{m.status}</em></div>
              <Button variant="gold" disabled={m.status === 'Подтверждено'} onClick={() => approve(m.id)}>Подтвердить</Button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function CalendarPage({ bookings, setBookings, leads }) {
  const [form, setForm] = useState({ client: '', type: 'Очный разбор', date: 'Сегодня', time: '19:00' });
  function addBooking() {
    if (!form.client.trim()) return;
    setBookings([{ id: Date.now(), ...form, status: 'Ожидает подтверждения' }, ...bookings]);
    setForm({ client: '', type: 'Очный разбор', date: 'Сегодня', time: '19:00' });
  }
  return (
    <div className="grid three">
      <Card>
        <h2>Новая запись</h2>
        <div className="form">
          <Input list="leadNames" placeholder="Имя клиента" value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} />
          <datalist id="leadNames">{leads.map((l) => <option key={l.id} value={l.name} />)}</datalist>
          <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            <option>Очный разбор</option><option>Онлайн-разбор</option><option>Первая тренировка</option><option>Персональная тренировка</option>
          </Select>
          <Input value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          <Input value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
          <Button onClick={addBooking}>Записать</Button>
        </div>
      </Card>
      <Card className="wide">
        <h2>Расписание</h2>
        <div className="tileGrid">{bookings.map((b) => <div className="tile" key={b.id}><b>{b.client}</b><p>{b.type}</p><strong>{b.date} • {b.time}</strong><em>{b.status}</em></div>)}</div>
      </Card>
    </div>
  );
}

function Platforms({ platforms, setPlatforms }) {
  const [form, setForm] = useState({ name: '', type: 'Telegram', district: '', rules: '', status: 'Можно публиковать' });
  function addPlatform() {
    if (!form.name.trim()) return;
    setPlatforms([{ id: Date.now(), ...form, lastPost: '—', result: '—' }, ...platforms]);
    setForm({ name: '', type: 'Telegram', district: '', rules: '', status: 'Можно публиковать' });
  }
  return (
    <div className="grid three">
      <Card>
        <h2>Добавить площадку</h2>
        <div className="form">
          <Input placeholder="Название" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{['Telegram','VK','Instagram','WhatsApp','Авито','Яндекс Услуги','Профи.ру','YouDo','Форум'].map(x => <option key={x}>{x}</option>)}</Select>
          <Input placeholder="Район" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} />
          <Input placeholder="Правила" value={form.rules} onChange={(e) => setForm({ ...form, rules: e.target.value })} />
          <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>{['Можно публиковать','Нужно согласование','Платная реклама','Публикация запрещена','Тестируется'].map(x => <option key={x}>{x}</option>)}</Select>
          <Button onClick={addPlatform}>Добавить</Button>
        </div>
      </Card>
      <Card className="wide"><h2>Площадки продвижения</h2><div className="cardsList">{platforms.map((p) => <div className="row" key={p.id}><div><b>{p.name}</b><p>{p.type} • {p.district}</p><p>{p.rules}</p></div><em>{p.status}</em></div>)}</div></Card>
    </div>
  );
}

function Templates({ templates, setTemplates }) {
  const [form, setForm] = useState({ title: '', type: 'Публикация', text: '' });
  function addTemplate() {
    if (!form.title.trim() || !form.text.trim()) return;
    setTemplates([{ id: Date.now(), ...form }, ...templates]);
    setForm({ title: '', type: 'Публикация', text: '' });
  }
  return (
    <div className="grid three">
      <Card><h2>Новый шаблон</h2><div className="form"><Input placeholder="Название" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{['Публикация','Личное сообщение','Follow-up','Сообщение админу','Ответ на цену'].map(x => <option key={x}>{x}</option>)}</Select><Textarea placeholder="Текст" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} /><Button onClick={addTemplate}>Сохранить</Button></div></Card>
      <Card className="wide"><h2>База шаблонов</h2><div className="cardsList">{templates.map((t) => <div className="template" key={t.id}><div><b>{t.title}</b><em>{t.type}</em></div><p>{t.text}</p></div>)}</div></Card>
    </div>
  );
}

function ClientForm({ setLeads }) {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', contact: '', goal: '', format: 'Очно', experience: '', limits: '' });
  function submit() {
    if (!form.name.trim()) return;
    setLeads((prev) => [{ id: Date.now(), name: form.name, source: 'Анкета клиента', goal: form.goal, format: form.format, status: 'Новый лид', nextStep: 'Ответить по анкете', followUp: 'Сегодня', notes: `Контакт: ${form.contact}. Опыт: ${form.experience}. Ограничения: ${form.limits}` }, ...prev]);
    setSent(true);
  }
  if (sent) return <Card className="center"><h2>Заявка создана</h2><p>Она появилась в разделе «Лиды».</p><Button onClick={() => setSent(false)}>Создать ещё одну</Button></Card>;
  return <Card className="clientForm"><h2>Анкета клиента</h2><p>Форма для записи на фитнес-разбор.</p><div className="form"><Input placeholder="Имя" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /><Input placeholder="Телефон / Telegram / WhatsApp" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} /><Input placeholder="Цель" value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })} /><Select value={form.format} onChange={(e) => setForm({ ...form, format: e.target.value })}><option>Очно</option><option>Онлайн</option><option>Пока не знаю</option></Select><Input placeholder="Опыт тренировок" value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} /><Input placeholder="Травмы / ограничения" value={form.limits} onChange={(e) => setForm({ ...form, limits: e.target.value })} /><Button onClick={submit}>Отправить заявку</Button></div></Card>;
}

function Analytics({ leads, platforms, outbox, bookings }) {
  const data = statuses.map((s) => ({ status: s, count: leads.filter((l) => l.status === s).length })).filter((x) => x.count);
  const max = Math.max(...data.map((x) => x.count), 1);
  return <div className="page"><div className="stats"><Stat label="Всего лидов" value={leads.length} /><Stat label="Записи" value={bookings.length} /><Stat label="Очередь" value={outbox.length} /><Stat label="Площадки" value={platforms.length} /></div><Card><h2>Статусы лидов</h2>{data.map((x) => <div className="barRow" key={x.status}><span>{x.status}</span><b>{x.count}</b><div><i style={{ width: `${(x.count / max) * 100}%` }} /></div></div>)}</Card></div>;
}

function Profile({ trainer, setTrainer }) {
  function onFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setTrainer({ ...trainer, photo: URL.createObjectURL(file) });
  }
  return <div className="grid three"><Card><h2>Фото тренера</h2><div className="photoBox">{trainer.photo ? <img src={trainer.photo} alt="trainer" /> : <span>Загрузи фото</span>}</div><label className="upload"><input type="file" accept="image/*" onChange={onFile} />Загрузить фото</label></Card><Card className="wide"><h2>Профиль</h2><div className="form twoCols"><Input value={trainer.name} onChange={(e) => setTrainer({ ...trainer, name: e.target.value })} /><Input value={trainer.role} onChange={(e) => setTrainer({ ...trainer, role: e.target.value })} /><Input value={trainer.club} onChange={(e) => setTrainer({ ...trainer, club: e.target.value })} /><Input value={trainer.location} onChange={(e) => setTrainer({ ...trainer, location: e.target.value })} /><Input value={trainer.formats} onChange={(e) => setTrainer({ ...trainer, formats: e.target.value })} /><Input value={trainer.offer} onChange={(e) => setTrainer({ ...trainer, offer: e.target.value })} /></div><div className="hint"><b>Описание:</b> {trainer.name} — {trainer.role.toLowerCase()} в {trainer.club}. Локация: {trainer.location}. Форматы: {trainer.formats}. Оффер: {trainer.offer}.</div></Card></div>;
}



function PublicLanding() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: '',
    contact: '',
    goal: 'Похудеть / подтянуть форму',
    format: 'Очно в HITFitness',
    time: '',
    comment: ''
  });

  function submit() {
    if (!form.name.trim() || !form.contact.trim()) return;
    const lead = {
      id: Date.now(),
      name: form.name,
      source: 'Страница /razbor',
      goal: form.goal,
      format: form.format.includes('Очно') ? 'Очно' : form.format.includes('Онлайн') ? 'Онлайн' : 'Не выбрал',
      status: 'Новый лид',
      nextStep: 'Связаться и подтвердить формат/время разбора',
      followUp: 'Сегодня',
      notes: `Контакт: ${form.contact}. Удобное время: ${form.time || 'не указано'}. Комментарий: ${form.comment || '—'}`,
      createdAt: new Date().toLocaleString('ru-RU')
    };
    try {
      const saved = JSON.parse(localStorage.getItem('timfit_leads') || '[]');
      localStorage.setItem('timfit_leads', JSON.stringify([lead, ...saved]));
      window.dispatchEvent(new Event('storage'));
    } catch {}
    setSent(true);
  }

  return (
    <div className="publicPage">
      <div className="publicWrap">
        <div className="publicTop">
          <div className="publicBrand">
            <div className="brandIcon">T</div>
            <div>
              <b>Тим • HITFitness</b>
              <span>ТРК «Лео Молл», м. Комендантский проспект</span>
            </div>
          </div>
          <a className="adminLink" href="/">Для тренера</a>
        </div>

        <div className="publicHero">
          <section className="heroCard">
            <span className="badge">Бесплатный фитнес-разбор</span>
            <h1>Начните тренировки без хаоса и ошибок</h1>
            <p>
              Меня зовут Тим. Я персональный тренер в HITFitness. Помогаю начать с нуля,
              похудеть, набрать мышечную массу, поставить технику и собрать понятный план тренировок.
            </p>
            <div className="heroGrid">
              <div><b>Очно</b><span>HITFitness, Лео Молл</span></div>
              <div><b>Онлайн</b><span>переписка или созвон</span></div>
              <div><b>15–20 минут</b><span>быстрый разбор цели</span></div>
              <div><b>Без давления</b><span>спокойно и по делу</span></div>
            </div>
          </section>

          <Card className="publicFormCard">
            {sent ? (
              <div className="successBox">
                <div className="successIcon">✓</div>
                <h2>Заявка отправлена</h2>
                <p>Тим увидит заявку и напишет, чтобы согласовать формат и время разбора.</p>
                <Button onClick={() => setSent(false)}>Отправить ещё одну</Button>
              </div>
            ) : (
              <>
                <h2>Записаться на разбор</h2>
                <p>Заполните короткую форму. Я посмотрю цель и подскажу, какой формат лучше: очно или онлайн.</p>
                <div className="guestNotice">
                  <b>Важно для очного формата:</b> гостевой визит в клуб стоит 1500 ₽. Если потом оформляете абонемент, эта сумма идёт в счёт абонемента. Сам разбор от меня — бесплатно.
                </div>
                <div className="form">
                  <Input placeholder="Ваше имя" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                  <Input placeholder="Telegram / WhatsApp / телефон" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} />
                  <Select value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })}>
                    <option>Похудеть / подтянуть форму</option>
                    <option>Набрать мышечную массу</option>
                    <option>Начать тренироваться с нуля</option>
                    <option>Поставить технику упражнений</option>
                    <option>Понять, почему нет результата</option>
                    <option>Другое</option>
                  </Select>
                  <Select value={form.format} onChange={(e) => setForm({ ...form, format: e.target.value })}>
                    <option>Очно в HITFitness</option>
                    <option>Онлайн-разбор</option>
                    <option>Пока не знаю</option>
                  </Select>
                  <Input placeholder="Когда удобно? Например: завтра вечером" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
                  <Textarea placeholder="Комментарий: опыт, ограничения, что сейчас не получается" value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} />
                  <Button onClick={submit}>Отправить заявку</Button>
                </div>
              </>
            )}
          </Card>
        </div>

        <div className="publicInfo">
          <Card><h2>Что входит</h2><p>Разберём цель, текущую ситуацию, ошибки и план на ближайший месяц.</p></Card>
          <Card><h2>Кому подойдёт</h2><p>Новичкам, тем, кто давно не тренировался, или тем, кто ходит в зал без результата.</p></Card>
          <Card><h2>Что дальше</h2><p>После заявки я напишу, уточню детали и предложу удобное время.</p></Card>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [tab, setTab] = useState('dashboard');
  const [trainer, setTrainer] = useStorage('timfit_trainer', defaultTrainer);
  const [leads, setLeads] = useStorage('timfit_leads', defaultLeads);
  const [platforms, setPlatforms] = useStorage('timfit_platforms', defaultPlatforms);
  const [templates, setTemplates] = useStorage('timfit_templates', defaultTemplates);
  const [outbox, setOutbox] = useStorage('timfit_outbox', defaultOutbox);
  const [bookings, setBookings] = useStorage('timfit_bookings', defaultBookings);

  if (window.location.pathname === '/razbor') {
    return <PublicLanding />;
  }

  const view = useMemo(() => {
    switch (tab) {
      case 'leads': return <Leads leads={leads} setLeads={setLeads} />;
      case 'messages': return <Messages templates={templates} outbox={outbox} setOutbox={setOutbox} />;
      case 'calendar': return <CalendarPage bookings={bookings} setBookings={setBookings} leads={leads} />;
      case 'platforms': return <Platforms platforms={platforms} setPlatforms={setPlatforms} />;
      case 'templates': return <Templates templates={templates} setTemplates={setTemplates} />;
      case 'client': return <ClientForm setLeads={setLeads} />;
      case 'analytics': return <Analytics leads={leads} platforms={platforms} outbox={outbox} bookings={bookings} />;
      case 'profile': return <Profile trainer={trainer} setTrainer={setTrainer} />;
      default: return <Dashboard leads={leads} platforms={platforms} outbox={outbox} bookings={bookings} setTab={setTab} />;
    }
  }, [tab, trainer, leads, platforms, templates, outbox, bookings]);

  return (
    <div className="app">
      <Sidebar tab={tab} setTab={setTab} />
      <main>
        <div className="mobileTabs">{tabs.map(([id, label]) => <button key={id} onClick={() => setTab(id)} className={tab === id ? 'active' : ''}>{label}</button>)}</div>
        <div className="content">
          <Header trainer={trainer} />
          <div className="notice"><b>Почти автоматизация:</b> приложение готовит тексты, лиды, напоминания и очередь сообщений, но публикацию подтверждает тренер. <a href="/razbor" target="_blank">Открыть страницу клиента</a></div>
          {view}
        </div>
      </main>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
